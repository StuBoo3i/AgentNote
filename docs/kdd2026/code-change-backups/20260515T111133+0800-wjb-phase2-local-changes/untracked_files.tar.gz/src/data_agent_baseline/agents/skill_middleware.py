from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from data_agent_baseline.agents.skills import (
    SkillDefinition,
    load_skill_library,
    recommend_skills,
)


@dataclass(slots=True)
class SkillsMiddleware:
    source_dirs: tuple[Path, ...]
    recursive_discovery: bool = True
    include_builtin_library: bool = True
    max_recommendations: int = 6
    _skill_library: tuple[SkillDefinition, ...] = ()

    def load_skills(self) -> tuple[SkillDefinition, ...]:
        self._skill_library = load_skill_library(
            source_dirs=self.source_dirs,
            recursive=self.recursive_discovery,
            include_builtin=self.include_builtin_library,
        )
        return self._skill_library

    def ensure_loaded(self) -> tuple[SkillDefinition, ...]:
        if not self._skill_library:
            return self.load_skills()
        return self._skill_library

    def list_skills(self) -> list[SkillDefinition]:
        return list(self.ensure_loaded())

    def match_skills(self, task_question: str, context_profile: dict[str, object]) -> list[SkillDefinition]:
        return recommend_skills(
            task_question,
            context_profile,
            skill_library=self.ensure_loaded(),
            max_skills=self.max_recommendations,
        )

    def create_skills_prompt_section(self) -> str:
        skills = self.list_skills()
        if not skills:
            return "Skills Library: none"

        lines: list[str] = []
        lines.append("Skills Library:")
        for skill in skills:
            lines.append(f"- {skill.name}: {skill.description}")
            if skill.path:
                lines.append(f"  path: {skill.path}")
        if self.source_dirs:
            rendered_dirs = ", ".join(path.as_posix() for path in self.source_dirs)
            lines.append(f"Skill source dirs: {rendered_dirs}")
        return "\n".join(lines)


def create_skills_middleware(
    *,
    source_dirs: Sequence[Path],
    recursive_discovery: bool = True,
    include_builtin_library: bool = True,
    max_recommendations: int = 6,
) -> SkillsMiddleware:
    return SkillsMiddleware(
        source_dirs=tuple(source_dirs),
        recursive_discovery=recursive_discovery,
        include_builtin_library=include_builtin_library,
        max_recommendations=max(1, max_recommendations),
    )
