# JSON Nested Extraction Reference

- Start from sample paths with `read_json`.
- Use `flatten_json.py` to inspect deep keys quickly.
- Normalize missing keys before aggregation.
