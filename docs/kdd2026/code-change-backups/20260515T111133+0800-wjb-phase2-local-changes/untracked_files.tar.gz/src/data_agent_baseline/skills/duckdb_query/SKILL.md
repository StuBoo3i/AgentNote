---
name: duckdb_query
description: Execute read-only DuckDB SQL for ad-hoc analytics on local files or attached DuckDB tables with safe row limiting.
trigger_keywords:
  - duckdb query
  - sql
  - group by
  - join
  - aggregate
  - window function
  - 数据查询
  - SQL
required_tools:
  - execute_skill_script_file
  - list_context
playbook: Write read-only SQL, then run scripts/run_duckdb_query.py. For file-based query, pass input_file and reference view `input_data` in SQL.
tags:
  - sql
  - analytics
---
# DuckDB Query

1. Confirm data source file path (if any) with `list_context`.
2. Write read-only SQL (`SELECT/WITH/FROM/DESCRIBE/SHOW/PRAGMA`).
3. Call `scripts/run_duckdb_query.py` with `sql` and optional `input_file`.
4. Use returned columns/rows for final answer formatting.

