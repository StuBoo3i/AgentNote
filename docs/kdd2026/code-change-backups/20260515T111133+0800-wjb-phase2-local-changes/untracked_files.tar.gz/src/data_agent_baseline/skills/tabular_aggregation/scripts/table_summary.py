import csv
import json
import sys
from pathlib import Path


def _load_args() -> dict:
    if len(sys.argv) < 2:
        return {}
    raw = sys.argv[1]
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def main(args: dict) -> None:
    input_file = str(args.get("input_file", "")).strip()
    if not input_file:
        print(json.dumps({"chunks": [{"output_type": "text", "content": "input_file is required"}]}))
        return

    path = Path(input_file)
    if not path.exists() or not path.is_file():
        print(
            json.dumps(
                {
                    "chunks": [
                        {
                            "output_type": "text",
                            "content": f"file not found: {input_file}",
                        }
                    ]
                },
                ensure_ascii=False,
            )
        )
        return

    with path.open("r", encoding="utf-8", errors="replace", newline="") as handle:
        reader = csv.reader(handle)
        rows = list(reader)

    if not rows:
        payload = {
            "chunks": [
                {"output_type": "text", "content": "empty csv"},
                {"output_type": "text", "content": "columns=0 rows=0"},
            ]
        }
        print(json.dumps(payload, ensure_ascii=False))
        return

    header = rows[0]
    data_rows = rows[1:]
    payload = {
        "chunks": [
            {
                "output_type": "text",
                "content": f"columns={len(header)} rows={len(data_rows)}",
            },
            {
                "output_type": "text",
                "content": "header=" + ",".join(header),
            },
        ]
    }
    print(json.dumps(payload, ensure_ascii=False))


if __name__ == "__main__":
    main(_load_args())
