# DuckDB Query Output Template

## Query Result
{{result}}

## Interpretation
{{insight}}
