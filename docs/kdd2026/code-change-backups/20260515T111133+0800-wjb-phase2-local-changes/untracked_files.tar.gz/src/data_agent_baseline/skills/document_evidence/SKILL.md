---
name: document_evidence
description: Extract factual evidence from markdown/text documents and keep units, dates, and qualifiers consistent.
trigger_extensions:
  - .md
  - .txt
trigger_keywords:
  - document
  - text
  - evidence
  - report
  - policy
  - 文档
  - 文本
  - 说明
required_tools:
  - read_doc
playbook: Read source passages directly, extract exact values and qualifiers, then produce traceable table answers.
tags:
  - evidence
  - document
---
# Document Evidence

1. Use `read_doc` to locate exact passages related to the question.
2. Keep value, unit, date range, and condition bound together during extraction.
3. Resolve ambiguity before answering; avoid inferred numbers without evidence.
4. Return only evidence-supported fields in the final table.
