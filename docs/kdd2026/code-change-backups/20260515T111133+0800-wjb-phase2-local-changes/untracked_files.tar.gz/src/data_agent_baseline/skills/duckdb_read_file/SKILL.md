---
name: duckdb_read_file
description: Read and profile local data files with DuckDB (CSV/TSV/JSON/Parquet/Excel), returning schema, row count, and sample rows for analysis tasks.
trigger_extensions:
  - .csv
  - .tsv
  - .json
  - .jsonl
  - .ndjson
  - .parquet
  - .pq
  - .xlsx
  - .xls
trigger_keywords:
  - duckdb
  - read file
  - inspect file
  - profile dataset
  - schema
  - preview
  - 数据探查
  - 文件分析
required_tools:
  - execute_skill_script_file
  - list_context
playbook: Use list_context to locate the file, then run scripts/read_file_with_duckdb.py with input_file and optional sample_rows. Use output schema and sample rows for follow-up reasoning.
tags:
  - profiling
  - file-reader
---
# DuckDB Read File

1. Use `list_context` first to confirm relative file path under task context.
2. Execute `scripts/read_file_with_duckdb.py` via `execute_skill_script_file`.
3. Prefer a small sample (`sample_rows` 20-50) before deeper analysis.
4. If schema is clear, continue with `duckdb_query` or regular tools.

