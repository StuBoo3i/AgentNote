from __future__ import annotations

import json
from pathlib import Path
import sys
from typing import Any
from urllib.parse import urlparse

REMOTE_SCHEMES = {"http", "https", "s3", "gs", "gcs", "r2", "az", "azure", "abfss"}


def _emit(payload: dict[str, Any], *, exit_code: int = 0) -> None:
    print(json.dumps(payload, ensure_ascii=False))
    raise SystemExit(exit_code)


def _load_args() -> dict[str, Any]:
    if len(sys.argv) < 2:
        return {}
    raw = sys.argv[1]
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _sql_quote(value: str) -> str:
    return value.replace("'", "''")


def _is_remote(path: str) -> bool:
    scheme = urlparse(path).scheme.lower()
    return scheme in REMOTE_SCHEMES


def _resolve_input_path(input_file: str, *, context_root: Path) -> tuple[str, str]:
    normalized = input_file.strip()
    if not normalized:
        raise ValueError("input_file is required.")

    if _is_remote(normalized):
        return normalized, "remote"

    candidate = Path(normalized)
    if not candidate.is_absolute():
        candidate = (context_root / candidate).resolve()
    else:
        candidate = candidate.resolve()

    resolved_root = context_root.resolve()
    if candidate != resolved_root and resolved_root not in candidate.parents:
        raise ValueError("input_file must stay inside task context directory.")
    if not candidate.exists() or not candidate.is_file():
        raise FileNotFoundError(f"input file not found: {candidate}")
    return candidate.as_posix(), "local"


def _prepare_extensions(con: Any, *, reader_hint: str, source_kind: str) -> None:
    if source_kind == "remote":
        try:
            con.execute("INSTALL httpfs")
        except Exception:
            pass
        con.execute("LOAD httpfs")

    if reader_hint == "excel":
        try:
            con.execute("INSTALL excel")
        except Exception:
            pass
        con.execute("LOAD excel")


def _build_relation_sql(path: str) -> tuple[str, str]:
    lower = path.lower().split("?", 1)[0]

    if lower.endswith((".xlsx", ".xls")):
        return f"SELECT * FROM read_xlsx('{_sql_quote(path)}')", "excel"
    if lower.endswith((".json", ".jsonl", ".ndjson")):
        return f"SELECT * FROM read_json_auto('{_sql_quote(path)}')", "json"
    if lower.endswith((".parquet", ".pq")):
        return f"SELECT * FROM read_parquet('{_sql_quote(path)}')", "parquet"
    if lower.endswith((".tsv", ".tab")):
        return f"SELECT * FROM read_csv_auto('{_sql_quote(path)}', delim='\t')", "tsv"

    # Default to DuckDB replacement scan for csv/txt and common flat files.
    return f"SELECT * FROM '{_sql_quote(path)}'", "auto"


def _rows_to_json(rows: list[tuple[Any, ...]]) -> list[list[Any]]:
    normalized: list[list[Any]] = []
    for row in rows:
        normalized.append([value for value in row])
    return normalized


def main(args: dict[str, Any]) -> None:
    context_root = Path.cwd()
    input_file = str(args.get("input_file", "")).strip()
    sample_rows = int(args.get("sample_rows", 20))
    sample_rows = max(1, min(sample_rows, 200))

    try:
        resolved_path, source_kind = _resolve_input_path(input_file, context_root=context_root)
    except Exception as exc:  # noqa: BLE001
        _emit(
            {
                "chunks": [
                    {
                        "output_type": "text",
                        "content": f"duckdb_read_file error: {exc}",
                    }
                ]
            },
            exit_code=1,
        )

    try:
        import duckdb
    except ModuleNotFoundError:
        _emit(
            {
                "chunks": [
                    {
                        "output_type": "text",
                        "content": (
                            "duckdb package is not installed in the runtime. "
                            "Install dependency `duckdb` before using duckdb_read_file skill."
                        ),
                    }
                ]
            },
            exit_code=1,
        )

    con = duckdb.connect(database=":memory:")
    relation_sql, reader_hint = _build_relation_sql(resolved_path)

    try:
        _prepare_extensions(con, reader_hint=reader_hint, source_kind=source_kind)
        schema_rows = con.execute(
            f"DESCRIBE SELECT * FROM ({relation_sql}) AS _src"
        ).fetchall()
        row_count = con.execute(
            f"SELECT count(*) AS row_count FROM ({relation_sql}) AS _src"
        ).fetchone()[0]

        sample_cursor = con.execute(
            f"SELECT * FROM ({relation_sql}) AS _src LIMIT {sample_rows}"
        )
        sample_data = sample_cursor.fetchall()
        sample_columns = [str(item[0]) for item in (sample_cursor.description or [])]
    except Exception as exc:  # noqa: BLE001
        _emit(
            {
                "chunks": [
                    {
                        "output_type": "text",
                        "content": f"duckdb_read_file failed for {resolved_path}: {exc}",
                    }
                ]
            },
            exit_code=1,
        )
    finally:
        con.close()

    schema_lines = [f"{name}: {dtype}" for name, dtype, *_ in schema_rows]
    payload = {
        "chunks": [
            {
                "output_type": "text",
                "content": (
                    f"source={resolved_path}; reader={reader_hint}; rows={row_count}; "
                    f"columns={len(sample_columns)}"
                ),
            },
            {
                "output_type": "text",
                "content": "schema:\n" + "\n".join(schema_lines),
            },
            {
                "output_type": "text",
                "content": json.dumps(
                    {
                        "columns": sample_columns,
                        "rows": _rows_to_json(sample_data),
                    },
                    ensure_ascii=False,
                ),
            },
        ]
    }
    _emit(payload, exit_code=0)


if __name__ == "__main__":
    main(_load_args())
