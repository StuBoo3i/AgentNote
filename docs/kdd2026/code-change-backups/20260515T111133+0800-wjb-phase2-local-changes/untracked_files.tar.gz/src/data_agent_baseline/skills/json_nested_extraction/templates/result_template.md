# JSON Result Template

## Extracted Keys
{{keys}}

## Validation Notes
{{notes}}
