# DuckDB Read File Notes

- Use relative paths under task context, for example `data.csv` or `subdir/data.parquet`.
- Main script: `scripts/read_file_with_duckdb.py`.
- Recommended args:
  - `input_file` (required)
  - `sample_rows` (optional, default 20, max 200)
- The script returns:
  - row/column summary
  - schema list
  - sample rows as JSON string
