---
name: cross_source_validation
description: Reconcile results across multiple source types and detect inconsistency before submission.
trigger_keywords:
  - compare
  - difference
  - match
  - reconcile
  - verify
  - 对比
  - 校验
required_tools:
  - execute_python
playbook: Compute candidate values independently per source, then compare in execute_python and apply deterministic tie-breaking.
tags:
  - cross-source
  - validation
---
# Cross Source Validation

1. Derive intermediate values independently from each source.
2. Use `execute_python` to compare values and identify mismatches.
3. Document tie-breaking or precedence rules explicitly.
4. Submit only reconciled outputs.
