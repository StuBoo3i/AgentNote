---
name: tabular_aggregation
description: Analyze CSV/TSV/Excel style tabular data and produce deterministic aggregations for benchmark answers.
trigger_extensions:
  - .csv
  - .tsv
  - .xlsx
  - .xls
trigger_keywords:
  - csv
  - excel
  - spreadsheet
  - average
  - sum
  - count
  - group by
  - ranking
  - 统计
  - 汇总
required_tools:
  - list_context
  - read_csv
  - execute_python
playbook: Preview schema with read_csv, validate row counts, then aggregate in execute_python and return only requested columns.
tags:
  - tabular
  - aggregation
  - csv
---
# Tabular Aggregation

1. Use `list_context` to confirm the target files and naming.
2. Use `read_csv` to inspect columns, sample rows, and data shape.
3. Optionally use `execute_skill_script_file` with `table_summary.py` for deterministic header/row-count checks.
4. Use `execute_python` for deterministic group/aggregate logic and explicit type conversion.
5. Verify result column order and row count before final `answer`.
