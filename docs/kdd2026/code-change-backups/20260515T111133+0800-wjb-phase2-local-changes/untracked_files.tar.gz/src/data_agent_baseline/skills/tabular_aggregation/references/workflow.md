# Tabular Aggregation Reference

- Use `execute_skill_script_file` with `table_summary.py` to get fast shape/header checks.
- Use `read_csv` for sampled rows, then `execute_python` for complex multi-step aggregation.
- Keep answer columns deterministic and in requested order.
