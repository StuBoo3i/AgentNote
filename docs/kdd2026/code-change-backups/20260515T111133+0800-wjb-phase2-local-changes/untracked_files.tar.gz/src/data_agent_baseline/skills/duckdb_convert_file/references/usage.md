# DuckDB Convert File Notes

- Main script: `scripts/convert_file_with_duckdb.py`.
- Supported output extensions:
  - `.parquet` / `.pq`
  - `.csv`
  - `.tsv` / `.tab`
  - `.json`
  - `.jsonl` / `.ndjson`
- If `output_file` is omitted, default is `<input_stem>.parquet`.
