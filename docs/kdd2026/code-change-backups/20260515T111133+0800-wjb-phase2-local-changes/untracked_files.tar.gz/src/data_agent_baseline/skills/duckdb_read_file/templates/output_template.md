# DuckDB Read File Output Template

## Dataset Summary
{{summary}}

## Schema
{{schema}}

## Sample Rows
{{sample_rows}}
