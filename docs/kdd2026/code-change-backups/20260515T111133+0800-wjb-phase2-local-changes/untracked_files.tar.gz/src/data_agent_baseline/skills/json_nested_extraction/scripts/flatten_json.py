import json
import sys
from pathlib import Path


def _load_args() -> dict:
    if len(sys.argv) < 2:
        return {}
    try:
        payload = json.loads(sys.argv[1])
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def _flatten(value, prefix=""):
    if isinstance(value, dict):
        for key, inner in value.items():
            next_prefix = f"{prefix}.{key}" if prefix else str(key)
            yield from _flatten(inner, next_prefix)
    elif isinstance(value, list):
        for index, inner in enumerate(value):
            next_prefix = f"{prefix}[{index}]"
            yield from _flatten(inner, next_prefix)
    else:
        yield prefix, value


def main(args: dict) -> None:
    input_file = str(args.get("input_file", "")).strip()
    max_items = int(args.get("max_items", 30))
    if not input_file:
        print(json.dumps({"chunks": [{"output_type": "text", "content": "input_file is required"}]}))
        return

    path = Path(input_file)
    if not path.exists():
        print(json.dumps({"chunks": [{"output_type": "text", "content": f"file not found: {input_file}"}]}))
        return

    payload = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    flat_items = list(_flatten(payload))[: max(1, max_items)]
    lines = [f"{key}={value}" for key, value in flat_items if key]
    print(json.dumps({"chunks": [{"output_type": "text", "content": "\\n".join(lines)}]}, ensure_ascii=False))


if __name__ == "__main__":
    main(_load_args())
