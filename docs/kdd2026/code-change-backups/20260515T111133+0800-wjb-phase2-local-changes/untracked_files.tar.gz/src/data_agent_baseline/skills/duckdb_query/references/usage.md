# DuckDB Query Notes

- Main script: `scripts/run_duckdb_query.py`.
- Allowed SQL classes: `SELECT`, `WITH`, `FROM`, `DESCRIBE`, `SHOW`, `PRAGMA`, `SUMMARIZE`, `EXPLAIN`.
- Mutating statements are blocked by script guard.
- If `input_file` is provided, the script builds a view `input_data`.
- In SQL, you can reference `input_data` directly, or use placeholder `__SOURCE__`.
