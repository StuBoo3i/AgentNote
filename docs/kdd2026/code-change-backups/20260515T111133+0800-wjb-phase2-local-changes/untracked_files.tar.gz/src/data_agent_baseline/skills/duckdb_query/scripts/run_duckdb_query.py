from __future__ import annotations

import json
from pathlib import Path
import re
import sys
from typing import Any
from urllib.parse import urlparse

READ_ONLY_PREFIXES = (
    "select",
    "with",
    "from",
    "describe",
    "show",
    "pragma",
    "summarize",
    "explain",
)
REMOTE_SCHEMES = {"http", "https", "s3", "gs", "gcs", "r2", "az", "azure", "abfss"}


def _emit(payload: dict[str, Any], *, exit_code: int = 0) -> None:
    print(json.dumps(payload, ensure_ascii=False))
    raise SystemExit(exit_code)


def _load_args() -> dict[str, Any]:
    if len(sys.argv) < 2:
        return {}
    try:
        parsed = json.loads(sys.argv[1])
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _sql_quote(value: str) -> str:
    return value.replace("'", "''")


def _is_remote(path: str) -> bool:
    scheme = urlparse(path).scheme.lower()
    return scheme in REMOTE_SCHEMES


def _resolve_local_path(input_file: str, *, context_root: Path) -> str:
    candidate = Path(input_file)
    if not candidate.is_absolute():
        candidate = (context_root / candidate).resolve()
    else:
        candidate = candidate.resolve()

    resolved_root = context_root.resolve()
    if candidate != resolved_root and resolved_root not in candidate.parents:
        raise ValueError("input_file must stay inside task context directory.")
    if not candidate.exists() or not candidate.is_file():
        raise FileNotFoundError(f"input file not found: {candidate}")
    return candidate.as_posix()


def _validate_read_only_sql(sql: str) -> str:
    normalized = sql.strip().rstrip(";").strip()
    lowered = normalized.lower()
    if not lowered:
        raise ValueError("sql is required.")
    if not lowered.startswith(READ_ONLY_PREFIXES):
        raise ValueError(
            "Only read-only SQL is allowed (SELECT/WITH/FROM/DESCRIBE/SHOW/PRAGMA/SUMMARIZE/EXPLAIN)."
        )
    if re.search(r"\b(insert|update|delete|drop|alter|truncate|copy\s+to|attach|detach|create)\b", lowered):
        raise ValueError("Mutating SQL keywords are not allowed in duckdb_query skill.")
    return normalized


def _build_file_view_sql(path: str) -> tuple[str, str]:
    lower = path.lower().split("?", 1)[0]
    if lower.endswith((".xlsx", ".xls")):
        return f"CREATE VIEW input_data AS SELECT * FROM read_xlsx('{_sql_quote(path)}')", "excel"
    if lower.endswith((".json", ".jsonl", ".ndjson")):
        return f"CREATE VIEW input_data AS SELECT * FROM read_json_auto('{_sql_quote(path)}')", "json"
    if lower.endswith((".parquet", ".pq")):
        return f"CREATE VIEW input_data AS SELECT * FROM read_parquet('{_sql_quote(path)}')", "parquet"
    if lower.endswith((".tsv", ".tab")):
        return f"CREATE VIEW input_data AS SELECT * FROM read_csv_auto('{_sql_quote(path)}', delim='\t')", "tsv"
    return f"CREATE VIEW input_data AS SELECT * FROM '{_sql_quote(path)}'", "auto"


def _format_rows(rows: list[tuple[Any, ...]]) -> list[list[Any]]:
    return [[value for value in row] for row in rows]


def main(args: dict[str, Any]) -> None:
    raw_sql = str(args.get("sql", "")).strip()
    input_file = str(args.get("input_file", "")).strip()
    row_limit = int(args.get("row_limit", 200))
    row_limit = max(1, min(row_limit, 1000))

    try:
        sql = _validate_read_only_sql(raw_sql)
    except Exception as exc:  # noqa: BLE001
        _emit({"chunks": [{"output_type": "text", "content": f"duckdb_query validation error: {exc}"}]}, exit_code=1)

    try:
        import duckdb
    except ModuleNotFoundError:
        _emit(
            {
                "chunks": [
                    {
                        "output_type": "text",
                        "content": (
                            "duckdb package is not installed in the runtime. "
                            "Install dependency `duckdb` before using duckdb_query skill."
                        ),
                    }
                ]
            },
            exit_code=1,
        )

    con = duckdb.connect(database=":memory:")
    source_hint = "none"

    try:
        if input_file:
            if _is_remote(input_file):
                try:
                    con.execute("INSTALL httpfs")
                except Exception:
                    pass
                con.execute("LOAD httpfs")
                resolved_input = input_file
            else:
                resolved_input = _resolve_local_path(input_file, context_root=Path.cwd())

            view_sql, source_hint = _build_file_view_sql(resolved_input)
            if source_hint == "excel":
                try:
                    con.execute("INSTALL excel")
                except Exception:
                    pass
                con.execute("LOAD excel")
            con.execute(view_sql)

        executable_sql = sql
        if input_file:
            executable_sql = executable_sql.replace("__SOURCE__", "input_data")

        lowered = executable_sql.lstrip().lower()
        needs_limit_wrap = lowered.startswith(("select", "with", "from", "explain")) and " limit " not in lowered

        if lowered.startswith("from "):
            executable_sql = "SELECT * " + executable_sql
            needs_limit_wrap = " limit " not in executable_sql.lower()

        if needs_limit_wrap and lowered.startswith(("select", "with", "from")):
            executable_sql = f"SELECT * FROM ({executable_sql.rstrip(';')}) AS _q LIMIT {row_limit}"

        cursor = con.execute(executable_sql)
        rows = cursor.fetchall()
        columns = [str(item[0]) for item in (cursor.description or [])]

    except Exception as exc:  # noqa: BLE001
        _emit(
            {
                "chunks": [
                    {
                        "output_type": "text",
                        "content": f"duckdb_query failed: {exc}",
                    }
                ]
            },
            exit_code=1,
        )
    finally:
        con.close()

    payload = {
        "chunks": [
            {
                "output_type": "text",
                "content": f"duckdb_query ok; source={source_hint}; rows={len(rows)}; columns={len(columns)}",
            },
            {
                "output_type": "text",
                "content": json.dumps(
                    {
                        "columns": columns,
                        "rows": _format_rows(rows),
                    },
                    ensure_ascii=False,
                ),
            },
        ]
    }
    _emit(payload, exit_code=0)


if __name__ == "__main__":
    main(_load_args())
