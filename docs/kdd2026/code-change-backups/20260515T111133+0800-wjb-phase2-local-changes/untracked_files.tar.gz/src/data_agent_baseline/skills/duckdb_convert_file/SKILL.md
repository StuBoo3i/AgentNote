---
name: duckdb_convert_file
description: Convert local data files between CSV/TSV/JSON/Parquet using DuckDB COPY for downstream standardized analysis.
trigger_keywords:
  - convert file
  - to parquet
  - to csv
  - to json
  - format conversion
  - 数据转换
required_tools:
  - execute_skill_script_file
  - list_context
playbook: Use scripts/convert_file_with_duckdb.py with input_file and output_file. Prefer parquet output for large tabular data.
tags:
  - conversion
  - parquet
---
# DuckDB Convert File

1. Confirm input file exists inside context.
2. Choose output path and target extension (`.parquet/.csv/.tsv/.json/.jsonl`).
3. Execute `scripts/convert_file_with_duckdb.py`.
4. Re-read converted file with `duckdb_read_file` for validation if needed.

