---
name: json_nested_extraction
description: Analyze nested JSON objects, flatten structures, and compute robust derived values from semi-structured records.
trigger_extensions:
  - .json
trigger_keywords:
  - json
  - nested
  - flatten
  - key
  - field
  - schema
  - 嵌套
  - 字段
required_tools:
  - read_json
  - execute_python
playbook: Inspect representative JSON with read_json, flatten target paths in execute_python, normalize missing values, then aggregate.
tags:
  - json
  - nested
  - normalization
---
# JSON Nested Extraction

1. Use `read_json` to inspect object shape and key paths before coding.
2. Optionally use `execute_skill_script_file` with `flatten_json.py` to quickly expose deep key paths.
3. In `execute_python`, normalize null/missing keys before any metric calculation.
4. Keep path access explicit and stable (avoid implicit assumptions about array order).
5. Return benchmark-ready table output with deterministic column naming.
