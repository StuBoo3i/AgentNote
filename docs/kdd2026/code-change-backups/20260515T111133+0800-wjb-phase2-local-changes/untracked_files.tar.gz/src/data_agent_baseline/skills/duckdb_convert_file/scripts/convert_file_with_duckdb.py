from __future__ import annotations

import json
from pathlib import Path
import sys
from typing import Any
from urllib.parse import urlparse

REMOTE_SCHEMES = {"http", "https", "s3", "gs", "gcs", "r2", "az", "azure", "abfss"}


def _emit(payload: dict[str, Any], *, exit_code: int = 0) -> None:
    print(json.dumps(payload, ensure_ascii=False))
    raise SystemExit(exit_code)


def _load_args() -> dict[str, Any]:
    if len(sys.argv) < 2:
        return {}
    try:
        parsed = json.loads(sys.argv[1])
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _sql_quote(value: str) -> str:
    return value.replace("'", "''")


def _is_remote(path: str) -> bool:
    return urlparse(path).scheme.lower() in REMOTE_SCHEMES


def _resolve_local_path(path: str, *, context_root: Path, must_exist: bool) -> Path:
    candidate = Path(path)
    if not candidate.is_absolute():
        candidate = (context_root / candidate).resolve()
    else:
        candidate = candidate.resolve()

    resolved_root = context_root.resolve()
    if candidate != resolved_root and resolved_root not in candidate.parents:
        raise ValueError("path must stay inside task context directory.")
    if must_exist and (not candidate.exists() or not candidate.is_file()):
        raise FileNotFoundError(f"file not found: {candidate}")
    return candidate


def _source_sql(input_path: str) -> tuple[str, str]:
    lower = input_path.lower().split("?", 1)[0]
    if lower.endswith((".xlsx", ".xls")):
        return f"SELECT * FROM read_xlsx('{_sql_quote(input_path)}')", "excel"
    if lower.endswith((".json", ".jsonl", ".ndjson")):
        return f"SELECT * FROM read_json_auto('{_sql_quote(input_path)}')", "json"
    if lower.endswith((".parquet", ".pq")):
        return f"SELECT * FROM read_parquet('{_sql_quote(input_path)}')", "parquet"
    if lower.endswith((".tsv", ".tab")):
        return f"SELECT * FROM read_csv_auto('{_sql_quote(input_path)}', delim='\t')", "tsv"
    return f"SELECT * FROM '{_sql_quote(input_path)}'", "auto"


def _copy_clause(output_path: str) -> tuple[str, str]:
    lower = output_path.lower()
    if lower.endswith((".parquet", ".pq")):
        return "(FORMAT PARQUET)", "parquet"
    if lower.endswith(".csv"):
        return "(FORMAT CSV, HEADER)", "csv"
    if lower.endswith((".tsv", ".tab")):
        return "(FORMAT CSV, HEADER, DELIMITER '\t')", "tsv"
    if lower.endswith(".json"):
        return "(FORMAT JSON, ARRAY true)", "json"
    if lower.endswith((".jsonl", ".ndjson")):
        return "(FORMAT JSON, ARRAY false)", "jsonl"
    raise ValueError("Unsupported output extension. Use .parquet/.csv/.tsv/.json/.jsonl")


def main(args: dict[str, Any]) -> None:
    context_root = Path.cwd()
    input_file = str(args.get("input_file", "")).strip()
    output_file = str(args.get("output_file", "")).strip()

    if not input_file:
        _emit({"chunks": [{"output_type": "text", "content": "input_file is required."}]}, exit_code=1)

    if not output_file:
        in_path = Path(input_file)
        output_file = in_path.with_suffix(".parquet").name if in_path.suffix else f"{in_path.name}.parquet"

    try:
        if _is_remote(input_file):
            resolved_input = input_file
            source_kind = "remote"
        else:
            resolved_input = _resolve_local_path(input_file, context_root=context_root, must_exist=True).as_posix()
            source_kind = "local"

        resolved_output = _resolve_local_path(output_file, context_root=context_root, must_exist=False).as_posix()
        Path(resolved_output).parent.mkdir(parents=True, exist_ok=True)

        source_sql, source_hint = _source_sql(resolved_input)
        copy_clause, target_format = _copy_clause(resolved_output)

    except Exception as exc:  # noqa: BLE001
        _emit({"chunks": [{"output_type": "text", "content": f"duckdb_convert_file resolve error: {exc}"}]}, exit_code=1)

    try:
        import duckdb
    except ModuleNotFoundError:
        _emit(
            {
                "chunks": [
                    {
                        "output_type": "text",
                        "content": (
                            "duckdb package is not installed in the runtime. "
                            "Install dependency `duckdb` before using duckdb_convert_file skill."
                        ),
                    }
                ]
            },
            exit_code=1,
        )

    con = duckdb.connect(database=":memory:")
    try:
        if source_kind == "remote":
            try:
                con.execute("INSTALL httpfs")
            except Exception:
                pass
            con.execute("LOAD httpfs")

        if source_hint == "excel":
            try:
                con.execute("INSTALL excel")
            except Exception:
                pass
            con.execute("LOAD excel")

        row_count = con.execute(f"SELECT count(*) FROM ({source_sql}) AS _src").fetchone()[0]
        con.execute(f"COPY ({source_sql}) TO '{_sql_quote(resolved_output)}' {copy_clause}")

    except Exception as exc:  # noqa: BLE001
        _emit({"chunks": [{"output_type": "text", "content": f"duckdb_convert_file failed: {exc}"}]}, exit_code=1)
    finally:
        con.close()

    output_size = Path(resolved_output).stat().st_size if Path(resolved_output).exists() else 0
    payload = {
        "chunks": [
            {
                "output_type": "text",
                "content": (
                    f"duckdb_convert_file ok; input={resolved_input}; output={resolved_output}; "
                    f"format={target_format}; rows={row_count}; bytes={output_size}"
                ),
            }
        ]
    }
    _emit(payload, exit_code=0)


if __name__ == "__main__":
    main(_load_args())
