# Tabular Result Template

## Summary
{{summary}}

## Checks
{{checks}}
