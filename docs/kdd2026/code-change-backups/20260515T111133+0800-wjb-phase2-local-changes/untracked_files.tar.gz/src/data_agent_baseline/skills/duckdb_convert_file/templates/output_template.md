# DuckDB Convert File Output Template

## Conversion Summary
{{summary}}

## Validation Suggestion
{{validation}}
