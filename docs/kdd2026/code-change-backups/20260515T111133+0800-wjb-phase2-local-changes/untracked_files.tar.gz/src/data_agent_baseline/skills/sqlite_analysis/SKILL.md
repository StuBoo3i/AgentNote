---
name: sqlite_analysis
description: Run schema-first SQL analysis on SQLite and DB assets using strict read-only queries.
trigger_extensions:
  - .sqlite
  - .db
trigger_keywords:
  - sql
  - sqlite
  - database
  - join
  - table
  - query
  - 数据库
  - 关联
required_tools:
  - inspect_sqlite_schema
  - execute_context_sql
playbook: Inspect schema first, then issue narrow SELECT queries with explicit columns and limits before final aggregation.
tags:
  - sql
  - sqlite
  - database
---
# SQLite Analysis

1. Start with `inspect_sqlite_schema` to verify table and column names.
2. Use `execute_context_sql` with explicit projection and low limits for iterative checks.
3. Keep queries read-only and deterministic.
4. Convert final SQL output into the exact answer table shape.
