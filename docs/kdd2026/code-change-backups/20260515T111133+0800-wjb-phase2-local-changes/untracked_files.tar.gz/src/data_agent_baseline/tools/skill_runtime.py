from __future__ import annotations

import ast
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from typing import Any, Sequence

from data_agent_baseline.benchmark.schema import PublicTask
import yaml

_MAX_TEXT_READ_CHARS = 200_000
_IMAGE_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".bmp",
    ".webp",
    ".svg",
    ".ico",
}
_SKILL_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,79}$")
_FRONTMATTER_RE = re.compile(
    r"^\s*---\s*\r?\n(?P<frontmatter>.*?)\r?\n---\s*(?P<body>.*)$",
    flags=re.DOTALL,
)


def default_skill_source_dirs() -> tuple[Path, ...]:
    project_root = Path(__file__).resolve().parents[3]
    return (
        project_root / "src" / "data_agent_baseline" / "skills",
        project_root / "skills",
    )


def _normalize_source_dirs(source_dirs: Sequence[Path] | None) -> tuple[Path, ...]:
    if source_dirs is None:
        return default_skill_source_dirs()
    normalized: list[Path] = []
    seen: set[str] = set()
    for item in source_dirs:
        resolved = Path(item).expanduser().resolve()
        key = resolved.as_posix().lower() if sys.platform.startswith("win") else resolved.as_posix()
        if key in seen:
            continue
        seen.add(key)
        normalized.append(resolved)
    return tuple(normalized)


def _validate_skill_name(skill_name: str) -> None:
    if not _SKILL_NAME_RE.match(skill_name):
        raise ValueError(
            "Invalid skill_name. Use letters, digits, underscore, hyphen; max length 80."
        )


def _parse_skill_frontmatter(skill_md_path: Path) -> dict[str, Any] | None:
    try:
        content = skill_md_path.read_text(encoding="utf-8")
    except OSError:
        return None
    content = content.lstrip("\ufeff")
    match = _FRONTMATTER_RE.match(content)
    if not match:
        return None
    frontmatter_text = str(match.group("frontmatter") or "")
    try:
        payload = yaml.safe_load(frontmatter_text) or {}
    except yaml.YAMLError:
        return None
    if not isinstance(payload, dict):
        return None
    return payload


def _load_skills_from_sources(
    source_dirs: Sequence[Path],
    *,
    recursive: bool,
) -> list[dict[str, Any]]:
    loaded: dict[str, dict[str, Any]] = {}
    for source_dir in source_dirs:
        if not source_dir.exists() or not source_dir.is_dir():
            continue
        pattern = "**/SKILL.md" if recursive else "*/SKILL.md"
        for skill_md_path in sorted(source_dir.glob(pattern), key=lambda item: item.as_posix()):
            payload = _parse_skill_frontmatter(skill_md_path)
            if payload is None:
                continue
            name = str(payload.get("name", "")).strip()
            description = str(payload.get("description", "")).strip()
            if not name or not description:
                continue
            loaded[name] = {
                "name": name,
                "description": description,
                "path": str(skill_md_path.resolve()),
                "raw": payload,
            }
    return list(loaded.values())


def _resolve_skill_dir(
    skill_name: str,
    *,
    source_dirs: Sequence[Path] | None,
    recursive: bool,
) -> Path:
    _validate_skill_name(skill_name)
    effective_source_dirs = _normalize_source_dirs(source_dirs)
    skills = _load_skills_from_sources(effective_source_dirs, recursive=recursive)
    for skill in skills:
        if skill.get("name") != skill_name:
            continue
        return Path(str(skill["path"])).resolve().parent

    # fallback for directory-name matching when metadata cannot be parsed
    for source_dir in effective_source_dirs:
        candidate = (source_dir / skill_name).resolve()
        if candidate.is_dir() and (candidate / "SKILL.md").exists():
            return candidate
    raise FileNotFoundError(f"Skill '{skill_name}' not found in configured source directories.")


def list_skill_summaries(
    *,
    source_dirs: Sequence[Path] | None = None,
    recursive: bool = True,
) -> list[dict[str, Any]]:
    effective_source_dirs = _normalize_source_dirs(source_dirs)
    skills = _load_skills_from_sources(effective_source_dirs, recursive=recursive)
    summaries: list[dict[str, Any]] = []
    for skill in skills:
        raw = skill.get("raw")
        if not isinstance(raw, dict):
            raw = {}
        tags = raw.get("tags")
        if isinstance(tags, str):
            normalized_tags = [item.strip() for item in tags.split(",") if item.strip()]
        elif isinstance(tags, list):
            normalized_tags = [str(item).strip() for item in tags if str(item).strip()]
        else:
            normalized_tags = []

        summaries.append(
            {
                "name": skill.get("name"),
                "description": skill.get("description"),
                "path": skill.get("path"),
                "source": "file",
                "tags": normalized_tags,
                "trigger_extensions": raw.get("trigger_extensions", []),
                "trigger_keywords": raw.get("trigger_keywords", []),
            }
        )
    return summaries


def _safe_join(base_dir: Path, relative_path: str) -> Path:
    candidate = (base_dir / relative_path).resolve()
    resolved_base = base_dir.resolve()
    if candidate != resolved_base and resolved_base not in candidate.parents:
        raise ValueError(f"Path escapes skill directory: {relative_path}")
    return candidate


def _detect_script_entry_function(code: str) -> tuple[str | None, list[str]]:
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None, []

    functions: dict[str, ast.FunctionDef | ast.AsyncFunctionDef] = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            functions[node.name] = node

    if not functions:
        return None, []

    target_func_name: str | None = None
    for node in tree.body:
        if not isinstance(node, ast.If):
            continue
        test = node.test
        if not isinstance(test, ast.Compare):
            continue
        if not isinstance(test.left, ast.Name) or test.left.id != "__name__":
            continue
        if len(test.comparators) != 1:
            continue
        comparator = test.comparators[0]
        if not isinstance(comparator, ast.Constant) or comparator.value != "__main__":
            continue

        for sub_node in ast.walk(node):
            if not isinstance(sub_node, ast.Call):
                continue
            if isinstance(sub_node.func, ast.Name) and sub_node.func.id in functions:
                target_func_name = sub_node.func.id
                break
        if target_func_name is not None:
            break

    if target_func_name is None:
        target_func_name = next(iter(functions.keys()))

    target_node = functions[target_func_name]
    params: list[str] = []
    for arg in target_node.args.posonlyargs:
        params.append(arg.arg)
    for arg in target_node.args.args:
        params.append(arg.arg)
    return target_func_name, params


def _adapt_args_for_script(code: str, args: dict[str, Any]) -> Any:
    if not args:
        return {}
    if len(args) == 1 and "args" in args and isinstance(args["args"], dict):
        args = dict(args["args"])

    _, params = _detect_script_entry_function(code)
    if not params:
        return args

    if len(params) == 1:
        param = params[0]
        if param in args:
            return args[param]
        if param in {"args", "kwargs", "params", "payload", "input"}:
            return args
        if "data" in args and len(args) == 1:
            return args["data"]
        if len(args) == 1:
            return next(iter(args.values()))
        return args

    if all(param in args for param in params):
        return {param: args[param] for param in params}
    return args


def _render_chunks(stdout: str, stderr: str, exit_code: int) -> tuple[bool, list[dict[str, str]]]:
    chunks: list[dict[str, str]] = []
    parsed = None
    if stdout.strip():
        try:
            parsed = json.loads(stdout.strip())
        except json.JSONDecodeError:
            parsed = None

    if isinstance(parsed, dict) and isinstance(parsed.get("chunks"), list):
        for item in parsed["chunks"]:
            if isinstance(item, dict):
                output_type = str(item.get("output_type", "text"))
                content = str(item.get("content", ""))
                if content:
                    chunks.append({"output_type": output_type, "content": content})
    elif stdout.strip():
        chunks.append({"output_type": "text", "content": stdout.strip()})

    if stderr.strip():
        chunks.append({"output_type": "text", "content": f"[stderr] {stderr.strip()}"})

    if exit_code != 0:
        chunks.append({"output_type": "text", "content": f"Exit code: {exit_code}"})

    if not chunks:
        chunks.append({"output_type": "text", "content": "Script executed successfully (no output)."})

    return exit_code == 0, chunks


def execute_skill_script_file(
    *,
    task: PublicTask,
    skill_name: str,
    script_file_name: str,
    args: dict[str, Any] | None = None,
    source_dirs: Sequence[Path] | None = None,
    recursive: bool = True,
    timeout_seconds: int = 120,
) -> dict[str, Any]:
    args = args or {}
    if not isinstance(args, dict):
        raise ValueError("execute_skill_script_file.args must be a JSON object.")

    skill_dir = _resolve_skill_dir(
        skill_name,
        source_dirs=source_dirs,
        recursive=recursive,
    )

    normalized_name = script_file_name.strip().lstrip("/\\")
    if normalized_name.startswith("scripts/") or normalized_name.startswith("scripts\\"):
        normalized_name = normalized_name[8:]
    if not normalized_name:
        raise ValueError("script_file_name must not be empty.")

    script_path = _safe_join(skill_dir / "scripts", normalized_name)
    if not script_path.exists() or not script_path.is_file():
        raise FileNotFoundError(f"Script file '{script_file_name}' not found in skill '{skill_name}'.")
    if script_path.suffix.lower() != ".py":
        raise ValueError("Only .py skill scripts are supported in this baseline.")

    code = script_path.read_text(encoding="utf-8", errors="replace")
    adapted_args = _adapt_args_for_script(code, args)
    if isinstance(adapted_args, dict):
        adapted_args = dict(adapted_args)
        adapted_args.setdefault("context_dir", str(task.context_dir))
        adapted_args.setdefault("task_dir", str(task.task_dir))
        adapted_args.setdefault("task_id", task.task_id)

    wrapper_code = (
        "import json\n"
        "import sys\n"
        "from pathlib import Path\n\n"
        f"SCRIPT_PATH = Path(r\"{script_path.as_posix()}\")\n"
        "RAW_ARGS = sys.argv[1] if len(sys.argv) > 1 else '{}'\n"
        "ARGS = json.loads(RAW_ARGS)\n"
        "sys.path.insert(0, str(SCRIPT_PATH.parent))\n"
        "sys.argv = ['script', json.dumps(ARGS, ensure_ascii=False)]\n"
        "globals_dict = {'__name__': '__main__', '__file__': str(SCRIPT_PATH)}\n"
        "code = SCRIPT_PATH.read_text(encoding='utf-8', errors='replace')\n"
        "exec(compile(code, str(SCRIPT_PATH), 'exec'), globals_dict, globals_dict)\n"
    )

    with tempfile.TemporaryDirectory(prefix="skill_exec_") as temp_dir:
        wrapper_path = Path(temp_dir) / "_skill_wrapper.py"
        wrapper_path.write_text(wrapper_code, encoding="utf-8")

        try:
            completed = subprocess.run(
                [
                    sys.executable,
                    str(wrapper_path),
                    json.dumps(adapted_args, ensure_ascii=False),
                ],
                cwd=str(task.context_dir),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=max(1, int(timeout_seconds)),
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            return {
                "ok": False,
                "error": f"Script execution timed out after {timeout_seconds} seconds.",
                "skill_name": skill_name,
                "script_file_name": script_file_name,
                "adapted_args": adapted_args,
                "chunks": [
                    {
                        "output_type": "text",
                        "content": f"Script execution timed out after {timeout_seconds} seconds.",
                    }
                ],
                "stdout": (exc.stdout or "").strip(),
                "stderr": (exc.stderr or "").strip(),
                "exit_code": None,
            }

    ok, chunks = _render_chunks(completed.stdout or "", completed.stderr or "", completed.returncode)
    return {
        "ok": ok,
        "skill_name": skill_name,
        "script_file_name": script_file_name,
        "script_path": str(script_path),
        "adapted_args": adapted_args,
        "chunks": chunks,
        "stdout": (completed.stdout or "").strip(),
        "stderr": (completed.stderr or "").strip(),
        "exit_code": completed.returncode,
    }


def get_skill_resource(
    *,
    task: PublicTask,
    skill_name: str,
    resource_path: str,
    args: dict[str, Any] | None = None,
    source_dirs: Sequence[Path] | None = None,
    recursive: bool = True,
    timeout_seconds: int = 120,
) -> dict[str, Any]:
    args = args or {}
    if not isinstance(args, dict):
        raise ValueError("get_skill_resource.args must be a JSON object when provided.")

    skill_dir = _resolve_skill_dir(
        skill_name,
        source_dirs=source_dirs,
        recursive=recursive,
    )
    normalized_resource = resource_path.strip().lstrip("/\\")
    if not normalized_resource:
        raise ValueError("resource_path must not be empty.")

    full_path = _safe_join(skill_dir, normalized_resource)
    ext = full_path.suffix.lower()
    if ext in _IMAGE_EXTENSIONS:
        return {
            "ok": False,
            "error": "Image resources are not supported by this model runtime.",
            "skill_name": skill_name,
            "resource_path": normalized_resource,
        }

    if (
        normalized_resource.startswith("scripts/")
        or normalized_resource.startswith("scripts\\")
    ) and ext == ".py":
        return execute_skill_script_file(
            task=task,
            skill_name=skill_name,
            script_file_name=normalized_resource,
            args=args,
            source_dirs=source_dirs,
            recursive=recursive,
            timeout_seconds=timeout_seconds,
        )

    if not full_path.exists() or not full_path.is_file():
        raise FileNotFoundError(
            f"Resource '{normalized_resource}' not found in skill '{skill_name}'."
        )

    text = full_path.read_text(encoding="utf-8", errors="replace")
    max_chars = int(args.get("max_chars", _MAX_TEXT_READ_CHARS))
    max_chars = max(1, min(max_chars, _MAX_TEXT_READ_CHARS))
    return {
        "ok": True,
        "type": "file",
        "skill_name": skill_name,
        "resource_path": normalized_resource,
        "content": text[:max_chars],
        "truncated": len(text) > max_chars,
    }
